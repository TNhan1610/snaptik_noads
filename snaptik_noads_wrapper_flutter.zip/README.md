
# Snaptik No-Ads Wrapper (Flutter, Android)
- Tab TikTok: auto dán clipboard vào ô URL của Snaptik, auto click "Download", chặn quảng cáo bằng CSS.
- Tab YouTube→MP3: mở mirror chuyển đổi, chặn bớt quảng cáo bằng CSS.
- Khi click link .jpg/.mp4/.mp3, app mở app ngoài (trình duyệt/DM) để tải bằng DownloadManager.

## Build
1) Cài Flutter SDK + Android SDK
2) `flutter pub get`
3) `flutter run -d android` (điện thoại bật USB debugging)
   hoặc `flutter build apk` để tạo APK

## Tuỳ chỉnh
- Sửa danh sách `snaptikMirrors` và `youtubeMirrors` trong `lib/main.dart`
- Điều chỉnh CSS/JS trong `adBlockCSS` và `buildInjectJS`
