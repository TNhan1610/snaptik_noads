
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import 'package:clipboard/clipboard.dart';
import 'package:url_launcher/url_launcher.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  if (Platform.isAndroid) {
    await InAppWebViewController.setWebContentsDebuggingEnabled(true);
  }
  runApp(const MyApp());
}

const snaptikMirrors = [
  "https://snaptik.vn/",
  "https://snaptik.app/",
  "https://snaptik.io/",
];

const youtubeMirrors = [
  "https://y2mate.tools/",
  "https://en4.y2mate.is/",
  "https://youtubemp3free.org/",
];

const adBlockCSS = """
iframe, .adsbygoogle, [id*=\"ad-\"], [class*=\"ad-\"], .banner, .advert, .ads, .ad, .gdpr, .cookie, .cookies { display: none !important; }
""";

const inputSelector = 'input[name="url"], input#url, input[type="text"]';

String buildInjectJS(String pasted) => """
(function(){
  try{
    const css = document.createElement(\"style\"); css.innerHTML = `$adBlockCSS`; document.head.appendChild(css);
    const inp = document.querySelector(\"$inputSelector\");
    if (inp) { inp.value = ${pasted.isNotEmpty ? '\"$pasted\"' : 'inp.value'}; }
    function clickBtn(){
      let btn = Array.from(document.querySelectorAll(\"button,input[type=submit]\")).find(b=>/download|tải/i.test((b.innerText||b.value||\"")));
      if(btn){ btn.click(); }
    }
    setTimeout(clickBtn, 600);
  }catch(e){}
})();
""";

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Downloader Lite',
      theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.blue),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with SingleTickerProviderStateMixin {
  late TabController _tab;
  String clipboardCache = "";
  InAppWebViewController? _controllerTikTok;
  InAppWebViewController? _controllerYT;

  @override
  void initState() {
    super.initState();
    _tab = TabController(length: 2, vsync: this);
    _loadClipboard();
  }

  Future<void> _loadClipboard() async {
    try {
      final txt = await FlutterClipboard.paste();
      setState(() => clipboardCache = txt.trim());
    } catch (_) {}
  }

  @override
  void dispose() {
    _tab.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Downloader Lite"),
        bottom: TabBar(
          controller: _tab,
          tabs: const [
            Tab(text: "TikTok (No-Ads)"),
            Tab(text: "YouTube → MP3"),
          ],
        ),
        actions: [
          IconButton(
            onPressed: () async { await _loadClipboard(); setState((){}); },
            icon: const Icon(Icons.paste),
            tooltip: "Nạp clipboard",
          ),
          PopupMenuButton<String>(
            itemBuilder: (ctx) => const [
              PopupMenuItem(value: "mirror_tt", child: Text("Đổi mirror Snaptik")),
              PopupMenuItem(value: "mirror_yt", child: Text("Đổi mirror YouTube")),
            ],
            onSelected: (v) async {
              if (v=="mirror_tt") {
                final sel = await _pickMirror(context, snaptikMirrors);
                if (sel!=null) {
                  _controllerTikTok?.loadUrl(urlRequest: URLRequest(url: WebUri(sel)));
                }
              } else if (v=="mirror_yt") {
                final sel = await _pickMirror(context, youtubeMirrors);
                if (sel!=null) {
                  _controllerYT?.loadUrl(urlRequest: URLRequest(url: WebUri(sel)));
                }
              }
            },
          )
        ],
      ),
      body: TabBarView(
        controller: _tab,
        children: [
          _TikTokTab(clipboardText: clipboardCache, onController: (c)=>_controllerTikTok=c),
          _YouTubeTab(onController: (c)=>_controllerYT=c),
        ],
      ),
    );
  }
}

class _TikTokTab extends StatefulWidget {
  final String clipboardText;
  final void Function(InAppWebViewController) onController;
  const _TikTokTab({required this.clipboardText, required this.onController});
  @override
  State<_TikTokTab> createState() => _TikTokTabState();
}

class _TikTokTabState extends State<_TikTokTab> {
  InAppWebViewController? _ctrl;
  String currentMirror = snaptikMirrors.first;
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(8),
          child: Row(
            children: [
              Expanded(child: Text(widget.clipboardText.isNotEmpty ? widget.clipboardText : "Hãy copy link TikTok trước…", maxLines: 1, overflow: TextOverflow.ellipsis)),
              const SizedBox(width: 8),
              ElevatedButton(
                onPressed: () async {
                  final js = buildInjectJS(widget.clipboardText);
                  if (_ctrl != null) await _ctrl!.evaluateJavascript(source: js);
                },
                child: const Text("Dán & Tải"),
              ),
            ],
          ),
        ),
        Expanded(
          child: InAppWebView(
            initialUrlRequest: URLRequest(url: WebUri(currentMirror)),
            initialSettings: InAppWebViewSettings(
              javaScriptEnabled: true,
              useOnDownloadStart: true,
              useShouldOverrideUrlLoading: true,
            ),
            onWebViewCreated: (c) async { _ctrl = c; widget.onController(c); },
            onLoadStop: (c, u) async {
              await c.injectCSSCode(source: adBlockCSS);
              final js = buildInjectJS(widget.clipboardText);
              await c.evaluateJavascript(source: js);
            },
            shouldOverrideUrlLoading: (c, nav) async {
              final uri = nav.request.url?.toString() ?? "";
              if (RegExp(r'\.(jpg|jpeg|png|mp4|webm|m4v)(\?.*)?$', caseSensitive: false).hasMatch(uri)) {
                try { await launchUrl(Uri.parse(uri), mode: LaunchMode.externalApplication); } catch(_){}
                return NavigationActionPolicy.CANCEL;
              }
              return NavigationActionPolicy.ALLOW;
            },
            onDownloadStartRequest: (c, req) async {
              final uri = req.url.toString();
              try { await launchUrl(Uri.parse(uri), mode: LaunchMode.externalApplication); } catch(_){}
            },
          ),
        ),
      ],
    );
  }
}

class _YouTubeTab extends StatefulWidget {
  final void Function(InAppWebViewController) onController;
  const _YouTubeTab({required this.onController});
  @override
  State<_YouTubeTab> createState() => _YouTubeTabState();
}

class _YouTubeTabState extends State<_YouTubeTab> {
  InAppWebViewController? _ctrl;
  String currentMirror = youtubeMirrors.first;
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(8),
          child: Row(
            children: [
              ElevatedButton(
                onPressed: () async {
                  final sel = await _pickMirror(context, youtubeMirrors);
                  if (sel!=null) { setState((){ currentMirror = sel; }); _ctrl?.loadUrl(urlRequest: URLRequest(url: WebUri(currentMirror))); }
                },
                child: const Text("Đổi mirror"),
              ),
              const SizedBox(width: 12),
              const Text("Chọn mirror sạch/nhanh để chuyển MP3."),
            ],
          ),
        ),
        Expanded(
          child: InAppWebView(
            initialUrlRequest: URLRequest(url: WebUri(currentMirror)),
            initialSettings: InAppWebViewSettings(
              javaScriptEnabled: true,
              useOnDownloadStart: true,
              useShouldOverrideUrlLoading: true,
            ),
            onWebViewCreated: (c) async { _ctrl = c; widget.onController(c); },
            onLoadStop: (c, u) async { await c.injectCSSCode(source: adBlockCSS); },
            shouldOverrideUrlLoading: (c, nav) async {
              final uri = nav.request.url?.toString() ?? "";
              if (RegExp(r'\.(mp3|m4a|webm|mp4)(\?.*)?$', caseSensitive: false).hasMatch(uri)) {
                try { await launchUrl(Uri.parse(uri), mode: LaunchMode.externalApplication); } catch(_){}
                return NavigationActionPolicy.CANCEL;
              }
              return NavigationActionPolicy.ALLOW;
            },
            onDownloadStartRequest: (c, req) async {
              final uri = req.url.toString();
              try { await launchUrl(Uri.parse(uri), mode: LaunchMode.externalApplication); } catch(_){}
            },
          ),
        ),
      ],
    );
  }
}

Future<String?> _pickMirror(BuildContext context, List<String> mirrors) async {
  return await showDialog<String>(
    context: context,
    builder: (ctx) => SimpleDialog(
      title: const Text("Chọn mirror"),
      children: mirrors.map((m) => SimpleDialogOption(
        onPressed: () => Navigator.pop(ctx, m),
        child: Text(m),
      )).toList(),
    ),
  );
}
